---
title       : Blue Flag Beaches in Greece
subtitle    : Shiny Application
author      : Konstantinos Koumoundouros
job         : Business Intelligence Developer
framework   : revealjs      # {io2012, html5slides, shower, dzslides, ...}
highlighter : highlight.js  # {highlight.js, prettify, highlight}
hitheme     : tomorrow      # 
widgets     : [mathjax]     # {mathjax, quiz, bootstrap}
mode        : standalone    # {standalone, draft}
knit        : slidify::knit2slides
---

## Blue Flag Beaches in Greece 

Shiny Application

---

## Story -about

The application presents the Blue Flag Beaches in Greece  
and provides a basic statistical information  
in a dynamic environment. 

*Components*
- Selection boxes
- Geographical map
- Plots
- Table

---

## Data

Data are from Geoadata.gov.gr  
for the years between 2008 and 2010.

*Data Preview* 

```
##     C_EDPP             NUMIND    COMMUNE                            PRELEV
## 1 64090703 GR1270090564090703   PALLINIS       PEFKOCHORI - HOTEL 'KOSTIS'
## 2 22010801 GR2220010122010801 KERKYRAION KONTOKALI - HOTEL 'KONTOKALI BAY'
## 3 22040601 GR2220040822040601   ESPERION                         ASTRAKERI
## 4 22090301 GR2220090922090301 MELITEIEON                              ISOS
## 5 22120201 GR2220120522120201   PARELION           ERMONES - HOTEL ERMONES
##               REGION   PROVINCE CODEAU LONGITUDE LATITUDE YEAR
## 1 KENTRIKI MAKEDONIA Chalkidiki      1  23.61264 39.98928 2008
## 2        IONIA NISIA    KERKYRA      1  19.87361 39.65028 2008
## 3        IONIA NISIA    KERKYRA      1  19.76944 39.80417 2008
## 4        IONIA NISIA    KERKYRA      1  19.94444 39.44028 2008
## 5        IONIA NISIA    KERKYRA      1  19.76722 39.62361 2008
```

---

## Data Structure



```r
str(data)
```

```
## 'data.frame':	1396 obs. of  10 variables:
##  $ C_EDPP   : Factor w/ 584 levels "03610101","04110301",..: 239 80 87 102 105 4 5 6 322 205 ...
##  $ NUMIND   : Factor w/ 584 levels "GR1110010171010601",..: 79 153 158 175 177 224 225 226 383 43 ...
##  $ COMMUNE  : Factor w/ 168 levels "ACHILLEION","AFANTOU",..: 103 66 38 86 106 25 29 29 51 62 ...
##  $ PRELEV   : Factor w/ 599 levels "ACHLADIA","ADELIANOS KAMPOS  - HOTEL 'RITHYMNA BEACH'",..: 336 192 73 149 114 401 224 225 282 309 ...
##  $ REGION   : chr  "KENTRIKI MAKEDONIA" "IONIA NISIA" "IONIA NISIA" "IONIA NISIA" ...
##  $ PROVINCE : chr  "Chalkidiki" "KERKYRA" "KERKYRA" "KERKYRA" ...
##  $ CODEAU   : int  1 1 1 1 1 1 1 1 1 1 ...
##  $ LONGITUDE: num  23.6 19.9 19.8 19.9 19.8 ...
##  $ LATITUDE : num  40 39.7 39.8 39.4 39.6 ...
##  $ YEAR     : chr  "2008" "2008" "2008" "2008" ...
```

```r
summary(data)
```

```
##       C_EDPP                    NUMIND                   COMMUNE    
##  04110301:   3   GR1110010171010801:   3   AGIOU NIKOLAOU    :  63  
##  06050102:   3   GR1110010571010901:   3   KALLITHEAS        :  45  
##  06190101:   3   GR1130020673020202:   3   SKIATHOU          :  26  
##  11010201:   3   GR1130021073020401:   3   SITHONIAS         :  25  
##  11010202:   3   GR1130021073020501:   3   ANATOLIKOU OLYMPOU:  24  
##  11080201:   3   GR1150010155010301:   3   GYTHEIOU          :  24  
##  (Other) :1378   (Other)           :1378   (Other)           :1189  
##             PRELEV        REGION            PROVINCE             CODEAU 
##  PLATYS GIALOS :  13   Length:1396        Length:1396        Min.   :1  
##  VOULA A       :  12   Class :character   Class :character   1st Qu.:1  
##  AGIOS ISIDOROS:   9   Mode  :character   Mode  :character   Median :1  
##  ASTERAS       :   9                                         Mean   :1  
##  KAMARI        :   9                                         3rd Qu.:1  
##  NYFIDA        :   9                                         Max.   :1  
##  (Other)       :1335                                                    
##    LONGITUDE        LATITUDE         YEAR          
##  Min.   :19.64   Min.   :34.87   Length:1396       
##  1st Qu.:22.61   1st Qu.:36.37   Class :character  
##  Median :23.80   Median :38.06   Mode  :character  
##  Mean   :23.81   Mean   :38.01                     
##  3rd Qu.:25.38   3rd Qu.:39.68                     
##  Max.   :28.27   Max.   :40.99                     
## 
```

---

## Links

Application hosting -[shinyapps.io](https://endoukoike.shinyapps.io/blueFlags/)  
Source code -[GitHub](https://github.com/EndouKoike/DevelopingDataProducts)  
Information about Blue Flags -[here](http://www.fee.global/blue-flag/)  
Information about Geoadata.gov.gr -[here](http://geodata.gov.gr/content/about-en/)
